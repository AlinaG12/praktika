const DARK_CLASS = "fa-moon-o"
const LIGHT_CLASS = "fa-sun-o"

const themeElement = document.getElementById("theme")
const rootElement  = document.getElementById("html")
const searchElement  = document.getElementById("search")
const searchContainerElement  = document.getElementById("search-container")
const searchInputElement  = document.getElementById("search-input")
const sliderElement = document.getElementById("slider")
const leftSlideElement = document.getElementById('left-slide')
const rightSlideElement = document.getElementById('right-slide')

const PAGES = {
    main: document.getElementById('main'),
    signIn: document.getElementById('sign-in'),
    signUp: document.getElementById('sign-up'),
    about: document.getElementById('about'),
    contacts: document.getElementById('contacts'),
    profile: document.getElementById('profile'),
}

const menuItemElements = document.getElementsByClassName('menu__item')

const getRandomInt = (max) => {
    return Math.floor(Math.random() * max);
  }

const sliders = [
    {
      title: "Космические исследования",
      img: "./images/1.webp",
      rating: getRandomInt(6)
    },
    {
      title: "Планеты Солнечной системы",
      img: "./images/2.webp",
      rating: getRandomInt(6)
    },
    {
      title: "Чёрные дыры",
      img: "./images/3.jpg",
      rating: getRandomInt(6)
    },
   {
      title: "Метеоры и кометы",
      img: "./images/4.jpg",
      rating: getRandomInt(6)
    },
  {
      title: "Галактики",
      img: "./images/5.jpg",
      rating: getRandomInt(6)
    },
  {
      title: "Астрофизика",
      img: "./images/6.jpg",
      rating: getRandomInt(6)
    },
  {
      title: "Робототехника в космосе",
      img: "./images/7.jpg",
      rating: getRandomInt(6)
    },
  {
      title: "Марс",
      img: "./images/8.jpg",
      rating: getRandomInt(6)
    },
  {
      title: "Луна",
      img: "./images/9.jpg",
      rating: getRandomInt(6)
    },
  {
      title: "Квазары",
      img: "./images/10.jpg",
      rating: getRandomInt(6)
    }
  ];

let showedSliders = [...sliders.slice(0, 6)]

let startPosition = 0
let endPosition = 5

const render = () => {
    
    
    let html = ''
    

    console.log(showedSliders)
    for (let i = 0; i < showedSliders.length; i++) {
        const item = showedSliders[i]
    
        let activeStars = ''
    
        for (let i = 0; i < item.rating; i++) {
            activeStars += '<i class="fa fa-star" aria-hidden="true"></i>'
        }
    
        if (item.rating < 5) {
            for (let i = 0; i < 5 - item.rating; i++) {
                activeStars += '<i class="fa fa-star white" aria-hidden="true"></i>'
            }
        }
    
    
        html += `
             <div class="slider__item">
                <img src="${item.img}" alt="">
                <div class="text">${item.title}</div>
                <div class="rating">
                    <div>
                        ${activeStars}
                    </div>
                    <div class="click">Подробнее</div>
                </div>
            </div>
        `
    }

    sliderElement.innerHTML = html
}




const handleThemeChange = () => {
    if (themeElement.classList.contains(DARK_CLASS)) {
        themeElement.classList.remove(DARK_CLASS)
        themeElement.classList.add(LIGHT_CLASS)
        rootElement.setAttribute("theme", "light")
    } else {
        themeElement.classList.remove(LIGHT_CLASS)
        themeElement.classList.add(DARK_CLASS)
        rootElement.setAttribute("theme", "dark")
    }
}

const handleNavigate = ({ target }) => {
    for (let i = 0; i < menuItemElements.length; i++) {
        menuItemElements[i].classList.remove('active')
    }
    const currentPage = target.getAttribute('page')
    PAGES[currentPage].style.display = 'flex'
    target.classList.add('active')


    Object.keys(PAGES)
        .filter(item => item !== currentPage)
        .map(item => PAGES[item].style.display = 'none')
}

const handleSearchClick = () => {
    searchElement.style.display = "none"
    searchInputElement.style.display = "block"
}

const handleSearch = ({ target }) => {
    const value = target.value

    if (!value) {
        rightSlideElement.style.display = 'block'
        leftSlideElement.style.display = 'block'
        showedSliders = [...sliders.slice(0, 6)]

    } else {
        const filtered = sliders.filter(item => item.title.indexOf(value) >= 0)

        rightSlideElement.style.display = 'none'
        leftSlideElement.style.display = 'none'
    
        let result = [...filtered]
    
        if (result.length > 6) {
            result = [result.slice(0, 6)]
        }
    
    
        showedSliders = [...result]
    }

    

    render()
}

const handleSlider = (type) => () => {
    if (type === 'left') {
        if (startPosition === 0) {
            showedSliders.splice(5, 1)
            showedSliders.splice(0, 0, sliders[sliders.length - 1])
            startPosition = sliders.length - 1

            if (endPosition - 1 < 0) {
                endPosition = sliders.length - 1
            } else {
                endPosition -= 1
            }
        } else {
            showedSliders.splice(5, 1)
            showedSliders.splice(0, 0, sliders[startPosition - 1])
            if (endPosition - 1 < 0) {
                endPosition = sliders.length - 1
            } else {
                endPosition -= 1
            }
            startPosition -= 1
        }
    } else if (type === 'right') {
        if (endPosition === sliders.length - 1) {
            showedSliders.splice(0, 1)
            showedSliders.splice(5, 0, sliders[0])
            if (startPosition + 1 > sliders.length - 1) {
                startPosition = 0
            } else {
                endPosition += 1
            }
            endPosition = 0
        } else {
            showedSliders.splice(0, 1)
            showedSliders.splice(5, 0, sliders[endPosition + 1])
            endPosition += 1
            startPosition += 1
        }
    }

    render()
}



themeElement.addEventListener('click', handleThemeChange)
searchElement.addEventListener('click', handleSearchClick)
leftSlideElement.addEventListener('click', handleSlider('left'))
rightSlideElement.addEventListener('click', handleSlider('right'))
searchInputElement.addEventListener('change', handleSearch)

for (let i = 0; i < menuItemElements.length; i++) {
    menuItemElements[i].addEventListener('click', handleNavigate)
}

render()